const Logo = () => {
  return (
    <div className="text-[30px] font-extrabold bg-gradient-to-r  from-primary to-secondary text-transparent bg-clip-text">
      کوئرا تسک منیجر
    </div>
  );
};

export default Logo;
