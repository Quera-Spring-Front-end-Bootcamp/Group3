function Home() {
  return <div>Home Pgae</div>;
}

export default Home;
